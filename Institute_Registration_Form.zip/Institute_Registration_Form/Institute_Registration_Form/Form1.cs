﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Institute_Registration_Form
{
    public partial class Form1 : Form
    {
        enum Category { Student, ITProfessional };
        enum Gender { Male, Female, Other};
        string cs = "server=.\\sqlexpress;integrated security= true;database=fendyl_projecta";
        SqlConnection conn;
        SqlCommand cmd;
        public int NationID;
        public int StateID;
        public int CityID;
        public string gender;

        public Form1()
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Today;
            dateTimePicker1.MinDate = DateTime.Today;
        }

        public void FetchNation()
        {
            comboBox1.Items.Clear();
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s = "select * from TableNation";
            SqlCommand cmd = new SqlCommand(s, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                comboBox1.Items.Add(dr["Nation_Name"].ToString());
                NationID = Convert.ToInt32(dr["Nation_ID"]);

            }
            dr.Close();
            conn.Close();
        }
        public void GetNationID()
        {
            try
            {
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                string s1 = "select Nation_ID from TableNation where Nation_Name='" + comboBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(s1, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    NationID = Convert.ToInt32(dr["Nation_ID"]);
                }
                // MessageBox.Show("NationID" + NationID);
                dr.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
        }

        public void GetStateID()
        {
            try
            {
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                string s1 = "select State_ID from TableState where State_Name='" + comboBox2.Text + "'";
                SqlCommand cmd = new SqlCommand(s1, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    StateID = Convert.ToInt32(dr["State_ID"]);
                }
                //  MessageBox.Show("StateID" + StateID);
                dr.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
        }
        public void GetCityID()
        {
            try
            {
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                string s1 = "select City_ID from TableCity where City_Name='" + comboBox3.Text + "'";
                SqlCommand cmd = new SqlCommand(s1, conn);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    CityID = Convert.ToInt32(dr["City_ID"]);
                }
                // MessageBox.Show("CID" + CityID);
                dr.Close();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
        }
        public void FetchState()
        {
            comboBox2.Items.Clear();
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1 = "Select State_ID,State_Name from TableState as SN inner join TableNation as TN on SN.Nation_ID = TN.Nation_ID where Nation_Name = '" + comboBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox2.Items.Add(dr["State_Name"].ToString());
                StateID = Convert.ToInt32(dr["State_ID"]);

            }
            dr.Close();
            conn.Close();
        }
        public void FetchStateId()
        {
            comboBox2.Items.Clear();
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1 = "Select State_ID from TableState where state_Name = '" + comboBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
               // comboBox2.Items.Add(dr["State_Name"].ToString());
                StateID = Convert.ToInt32(dr["State_ID"]);

            }
            dr.Close();
            conn.Close();
        }
        public void FetchCity()
        {
            comboBox3.Items.Clear();

            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1 = "Select City_ID,City_Name from TableCity as TC inner join TableState as TN on TC.State_ID=TN.State_ID where State_Name = '" + comboBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["City_Name"].ToString());
                CityID = Convert.ToInt32(dr["City_ID"]);

            }
            dr.Close();
            conn.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FetchNation();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            FetchState();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox3.Text = "";
            FetchCity();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Text = "1000";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox2.Text = "3000";
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                decimal balamt = 0;

                if (radioButton1.Checked == true)
                {
                    

                    balamt = Convert.ToDecimal(textBox2.Text) - Convert.ToDecimal(textBox3.Text);
                    textBox4.Text = balamt.ToString();
                }

                else if (radioButton2.Checked == true)
                {
                    balamt = Convert.ToDecimal(textBox2.Text) - Convert.ToDecimal(textBox3.Text);
                    textBox4.Text = balamt.ToString();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Enter Number Only");
            }
        }


        //--------------------------------------------------------------------------------------
        public void insertRegAddress()
        {
           

            SqlConnection conn = new SqlConnection(cs);
            conn.Open();

            string str = "select max(courseregid) from tablecourseregdetail";
            SqlCommand cmd11 = new SqlCommand(str, conn);
            int mcid = Convert.ToInt32(cmd11.ExecuteScalar());


            string s2 = "insert into TableRegAddress values(@CourseRegID,@NationID,@StateID,@CityID)";
            SqlCommand cmd1 = new SqlCommand(s2, conn);
            cmd1.Parameters.Add("@CourseRegID", SqlDbType.Int).Value = mcid;
            cmd1.Parameters.Add("@NationID", SqlDbType.Int).Value = NationID;
            cmd1.Parameters.Add("@StateID", SqlDbType.Int).Value = StateID;
            cmd1.Parameters.Add("@CityID", SqlDbType.Int).Value = CityID;
            cmd1.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Stored TableRegAddress");
        }
        public void insertFeeDetail(DateTime paydate)
        {
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();

            string str = "select max(courseregid) from tablecourseregdetail";
            SqlCommand cmd11 = new SqlCommand(str, conn);
            int mcid = Convert.ToInt32(cmd11.ExecuteScalar());

            string s2 = "insert into TableFeeDetail values(@CourseRegID,@TotalAmount,@MinPer,@PaidAmount,@BalAmount,@PaidDate)";
            SqlCommand cmd1 = new SqlCommand(s2, conn);
            cmd1.Parameters.Add("@CourseRegID", SqlDbType.Int).Value = mcid;
            cmd1.Parameters.Add("@TotalAmount", SqlDbType.Decimal).Value = textBox2.Text;
            cmd1.Parameters.Add("@MinPer", SqlDbType.Int).Value = fta;
            cmd1.Parameters.Add("@PaidAmount", SqlDbType.Int).Value = textBox3.Text;
            cmd1.Parameters.Add("@BalAmount", SqlDbType.Int).Value = textBox4.Text;
            cmd1.Parameters.Add("@PaidDate", SqlDbType.DateTime).Value = paydate;
            cmd1.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Stored TableFeeDetail");
        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            // Get the selected payment date from the DateTimePicker
            DateTime selectedDate = dateTimePicker1.Value;

            // Validate that the selected date is not earlier than today
            if (selectedDate.Date < DateTime.Today)
            {
                MessageBox.Show("Please select a payment date that is on or after today's date.", "Invalid Date Selection", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Process the payment with the selected date
            ProcessPayment(selectedDate);
        }
        float fta = 0.0f;
        private void ProcessPayment(DateTime paymentDate)
        {
            // Process the payment with the selected date
            // ...

            try
            {
                GetNationID();

                GetStateID();
                GetCityID();

                Category selectedCategory;
                string category = null;
                int catid = 0;
                if (radioButton1.Checked)
                {
                    selectedCategory = Category.Student;

                }
                else
                {
                    selectedCategory = Category.ITProfessional;
                }

                // Use the selected category to process the registration
                switch (selectedCategory)
                {
                    case Category.Student:
                        // Process student registration
                        category = "Student";
                        catid = 1;
                        break;
                    case Category.ITProfessional:
                        // Process IT professional registration
                        category = "IT Professional";
                        catid = 2;
                        break;
                    default:
                        // Handle invalid selection
                        MessageBox.Show("invalid category");
                        break;
                }

                Gender selectedGender;
                int gender = 0;
                if (radioButton3.Checked)
                {
                    selectedGender = Gender.Male;
                }
                else if (radioButton4.Checked)
                {
                    selectedGender = Gender.Female;
                }
                else
                {
                    selectedGender = Gender.Other;
                }
                //  MessageBox.Show(selectedGender.ToString());
                // Use the selected category to process the registration
                switch (selectedGender)
                {
                    case Gender.Male:
                        // Process student registration
                        gender = 1;
                        break;
                    case Gender.Female:
                        // Process IT professional registration
                        gender = 2;
                        break;
                    case Gender.Other:
                        // Process IT professional registration
                        gender = 3;
                        break;
                    default:
                        // Handle invalid selection
                        MessageBox.Show("invalid gender");
                        break;
                }
                if (category == "Student")
                {
                    int ta = Convert.ToInt32(textBox2.Text);
                    int pa = Convert.ToInt32(textBox3.Text);
                    int ba = Convert.ToInt32(textBox4.Text);
                    fta = ta * 0.50f;
                    if (pa < fta)
                    {
                        MessageBox.Show("pay atleast 50% of total amount");
                    }
                    else
                    {

                        SqlConnection conn = new SqlConnection(cs);
                        conn.Open();
                        string s1 = "insert into TableCourseRegDetail values(@CategoryInd,@FullName,@GenderInd)";
                        SqlCommand cmd = new SqlCommand(s1, conn);
                        cmd.Parameters.Add("@CategoryInd", SqlDbType.Int).Value = catid;
                        cmd.Parameters.Add("@FullName", SqlDbType.VarChar).Value = textBox1.Text;
                        cmd.Parameters.Add("@GenderInd", SqlDbType.VarChar).Value = gender;
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Record Store Successfully in CourseRegDetail");
                        insertRegAddress();
                        insertFeeDetail(paymentDate);
                    }
                }
                else if (category == "IT Professional")
                {

                    int ta = Convert.ToInt32(textBox2.Text);
                    int pa = Convert.ToInt32(textBox3.Text);
                    int ba = Convert.ToInt32(textBox4.Text);
                    fta = ta * 0.80f;
                    if (pa < fta)
                    {
                        MessageBox.Show("pay atleast 80% of total amount");
                    }
                    else
                    {

                        SqlConnection conn = new SqlConnection(cs);
                        conn.Open();
                        string s1 = "insert into TableCourseRegDetail values(@CategoryInd,@FullName,@GenderInd)";
                        SqlCommand cmd = new SqlCommand(s1, conn);
                        cmd.Parameters.Add("@CategoryInd", SqlDbType.Int).Value = catid;
                        cmd.Parameters.Add("@FullName", SqlDbType.VarChar).Value = textBox1.Text;
                        cmd.Parameters.Add("@GenderInd", SqlDbType.VarChar).Value = gender;
                        cmd.ExecuteNonQuery();
                        conn.Close();
                        MessageBox.Show("Record Store Successfully in CourseRegDetail");
                        insertRegAddress();
                        insertFeeDetail(paymentDate);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
            finally
            {
                // Clear();
            }

        }

        //--------------------------------------------------------------------------------------------

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("NID " + NationID);
            MessageBox.Show("SID " + StateID);
            MessageBox.Show("CID " + CityID);
            FetchCity();
            FetchNation();
            FetchState();
            Clear();
        }

        public void Clear()
        {
            radioButton1.Checked= false;
            radioButton2.Checked= false;
            radioButton3.Checked= false;
            radioButton4.Checked= false;
            radioButton5.Checked= false;
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            textBox1.Text= string.Empty;
            textBox2.Text= string.Empty;
            textBox3.Text= string.Empty;
            textBox4.Text= string.Empty;
            dateTimePicker1.Text = DateTime.Now.ToString();

        }
    }
}
