﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Product_Store
{
    public partial class Form1 : Form
    {
        enum Nationality { Indian, NRI };

        string cs = "server=.\\sqlexpress;integrated security=true;database=fendyl_projectb";
        SqlConnection conn;
        SqlCommand cmd;
        decimal totalamt;
        int PcatID, PID;
        int CGST, SGST, IGST;
        double CGST_Value, IGST_Value, SGST_Value;

        // public int totalamt;
        public Form1()
        {
            InitializeComponent();
            dateTimePicker1.Value = DateTime.Today;
            dateTimePicker1.MinDate = DateTime.Today;
        }

        public void GetCategory()
        {
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1 = "select * from TableProductCategory";
            SqlCommand cmd = new SqlCommand(s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["Product_Type_Name"].ToString());
            }
            dr.Close();
            conn.Close();
        }
        public void GetProduct()
        {
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1 = "select Product_Name from TableProduct as TP inner join TableProductCategory as TPC on TP.Product_Category_ID=TPC.Product_Category_ID where Product_Type_Name='"+comboBox1.Text+"'";
            SqlCommand cmd = new SqlCommand(s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                comboBox2.Items.Add(dr["Product_Name"].ToString());
            }
            dr.Close();
            conn.Close();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            GetCategory();           
        }

        public void GetGstdetail()
        {
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1 = "select CGST,SGST,IGST from TableProductGSTDetails as tpgst inner join tableproductcategory as tpc on tpgst.product_gst_id=tpc.product_gst_id  where product_type_name='"+comboBox1.Text+"'";
            SqlCommand cmd = new SqlCommand (s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox5.Text = dr["CGST"].ToString();
                textBox6.Text = dr["SGST"].ToString();
                IGST = Convert.ToInt32(dr["IGST"].ToString());
            }
            dr.Close();
            conn.Close();

            //code to check nationality
            Nationality selectedNationality;
            string nationality = null;
            
            if (radioButton1.Checked)
            {
                selectedNationality = Nationality.Indian;

            }
            else
            {
                selectedNationality = Nationality.NRI;
            }

            // Use the selected category to process the registration
            switch (selectedNationality)
            {
                case Nationality.Indian:
                    // Process student registration
                    nationality = "Indian";
                    
                    break;
                case Nationality.NRI:
                    // Process IT professional registration
                    nationality = "NRI";
                    
                    break;
                default:
                    // Handle invalid selection
                    MessageBox.Show("invalid nationality");
                    break;
            }




            if (nationality=="Indian")
            {
                IGST= Convert.ToInt32(textBox5.Text)+Convert.ToInt32(textBox6.Text);
                textBox7.Text=Convert.ToString(IGST);
                //textBox9.Text=Convert.ToString()
            }
            else
            {
                textBox7.Text=Convert.ToString(IGST);
            }
            CalculateGST();



        }
        public void CalculateGST()
        {
            //CGST_Value = (Convert.ToDouble(textBox5.Text) / 100) * Convert.ToDouble(textBox8.Text);
            //SGST_Value = (Convert.ToDouble(textBox6.Text) / 100) * Convert.ToDouble(textBox8.Text);
            //IGST_Value = (Convert.ToDouble(textBox7.Text) / 100) * Convert.ToDouble(textBox8.Text);
            //MessageBox.Show("C " + CGST_Value);
            //MessageBox.Show("S " + SGST_Value);
            //MessageBox.Show("I " + IGST_Value);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Text = "";
            comboBox2.Items.Clear();
            GetProduct();
           GetGstdetail();

        }
        public void GetproductCatID()
        {
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1= "select Product_Category_ID from TableProductCategory where Product_Type_Name='"+comboBox1.Text+"'";
            SqlCommand cmd = new SqlCommand (s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                PcatID = Convert.ToInt32(dr["Product_Category_ID"].ToString());
               
            }
            dr.Close();
            conn.Close();
        }
        public void GetProduct_ID()
        {
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1= "select ProductID from TableProduct where Product_Name='" + comboBox2.Text+"'";
            SqlCommand cmd = new SqlCommand (s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                PID = Convert.ToInt32(dr["ProductID"].ToString());               
            }
            dr.Close();
            conn.Close();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text=="" && textBox3.Text=="" && textBox4.Text=="")
            {
                MessageBox.Show("You can not left blank any field");
            }
            else
            {
                GetproductCatID();
                GetProduct_ID();
                SqlConnection conn = new SqlConnection(cs);
                conn.Open();
                string s1 = "insert into TableInvoiceDetails values (@Customer_Name,@Customer_Contact,@Product_Category_ID,@Product_ID,@Residential_Type_ID,@Invoice_Date,@Quantity,@price,@CGST,@SGST,@IGST,@CGST_Value,@SGST_Value,@IGST_Value,@Total_Amount)";
                SqlCommand cmd = new SqlCommand(s1, conn);
                //cmd.Parameters.Add("Invoice_Detail_ID",SqlDbType.Int)=;
                cmd.Parameters.Add("Customer_Name", SqlDbType.VarChar).Value = textBox1.Text;
                cmd.Parameters.Add("Customer_Contact", SqlDbType.VarChar).Value = textBox2.Text;
                cmd.Parameters.Add("Product_Category_ID", SqlDbType.VarChar).Value = PcatID;
                cmd.Parameters.Add("Product_ID", SqlDbType.Int).Value = PID;
                cmd.Parameters.Add("Residential_Type_ID", SqlDbType.Int).Value = 101;
                cmd.Parameters.Add("Invoice_Date", SqlDbType.DateTime).Value = dateTimePicker1.Text;
                cmd.Parameters.Add("Quantity", SqlDbType.Int).Value = textBox3.Text;
                cmd.Parameters.Add("price", SqlDbType.Int).Value = textBox4.Text;
                cmd.Parameters.Add("CGST", SqlDbType.Int).Value = textBox5.Text;
                cmd.Parameters.Add("SGST", SqlDbType.Int).Value = textBox6.Text;
                cmd.Parameters.Add("IGST", SqlDbType.Int).Value = textBox7.Text;
                cmd.Parameters.Add("CGST_Value", SqlDbType.Int).Value = textBox10.Text;
                cmd.Parameters.Add("SGST_Value", SqlDbType.Int).Value =textBox11.Text;
                cmd.Parameters.Add("IGST_Value", SqlDbType.Int).Value = textBox12.Text;
                cmd.Parameters.Add("Total_Amount", SqlDbType.Int).Value = textBox9.Text;
                cmd.ExecuteNonQuery();
                conn.Close();
                Clear();
                MessageBox.Show("Record inserted in TableInvoiceDetails");
            }

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            CalculateGST();
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                comboBox1.Text = "Select";
                comboBox2.Text = "Select";
                textBox3.Text = "0";
                textBox4.Text = "0";
                textBox5.Text = "0";
                textBox6.Text = "0";
                textBox7.Text = "0";
                textBox8.Text = "0";
                textBox9.Text = "0";
                textBox10.Text = "0";
                textBox11.Text = "0";
                textBox12.Text = "0";




            }
          
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {

            }
            else
            {
                if (radioButton1.Checked)
                {

                    totalamt = Convert.ToDecimal(textBox3.Text) * Convert.ToDecimal(textBox4.Text);
                    textBox8.Text = Convert.ToString(totalamt);

                    float cgst = (Convert.ToSingle(textBox5.Text) / 100.0f) * Convert.ToSingle(textBox8.Text);
                    textBox10.Text = cgst.ToString();
                    float sgst = (Convert.ToSingle(textBox6.Text) / 100.0f) * Convert.ToSingle(textBox8.Text);
                    textBox11.Text = sgst.ToString();
                    float igst = (Convert.ToSingle(textBox7.Text) / 100.0f) * Convert.ToSingle(textBox8.Text);
                    textBox12.Text = igst.ToString();
                    float netamt = Convert.ToSingle(textBox8.Text) + Convert.ToSingle(textBox12.Text);
                    textBox9.Text = netamt.ToString();
                }
                else
                {
                    totalamt = Convert.ToDecimal(textBox3.Text) * Convert.ToDecimal(textBox4.Text);
                    textBox8.Text = Convert.ToString(totalamt);

                      float cgst = (Convert.ToSingle(textBox5.Text) / 100.0f) * Convert.ToSingle(textBox8.Text);
                    textBox10.Text = cgst.ToString();
                    float sgst = (Convert.ToSingle(textBox6.Text) / 100.0f) * Convert.ToSingle(textBox8.Text);
                    textBox11.Text = sgst.ToString();
                    float igst = (Convert.ToSingle(textBox7.Text) / 100.0f) * Convert.ToSingle(textBox8.Text);
                    textBox12.Text = igst.ToString();
                    float netamt = Convert.ToSingle(textBox8.Text) + Convert.ToSingle(textBox12.Text);
                    textBox9.Text = netamt.ToString();
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(cs);
            conn.Open();
            string s1 = "select Productprice from TableProduct where Product_Name='" + comboBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(s1, conn);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                textBox4.Text= dr["Productprice"].ToString();
            }
            dr.Close();
            conn.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {           
         


        }

        public void Clear()
        {
            dateTimePicker1.Value = DateTime.Today;
            comboBox1.Text = "Select";
            comboBox2.Text = "Select";
            textBox3.Text = "0";
            textBox4.Text = "0";
            textBox5.Text = "0";
            textBox6.Text = "0";
            textBox7.Text = "0";
            textBox8.Text = "0";
            textBox9.Text = "0";
            textBox10.Text = "0";
            textBox11.Text = "0";
            textBox12.Text = "0";
            textBox1.Clear();
            textBox2.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
           Clear();
        }

       
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                comboBox1.Text = "Select";
                comboBox2.Text = "Select";
                textBox3.Text="0";
               textBox4.Text = "0" ;
                textBox5.Text = "0" ;
                textBox6.Text = "0" ;
                textBox7.Text = "0" ;
                textBox8.Text = "0" ;
                textBox9.Text = "0" ;
                textBox10.Text = "0" ;
                textBox11.Text = "0" ;
                textBox12.Text = "0" ;
              
               

                
            }
        }
    }
}
